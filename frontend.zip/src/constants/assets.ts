export const infoSiteAsset = (fileName: string) => `/assets/infosite-pictures/${fileName}`;
