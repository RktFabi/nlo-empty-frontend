// Payment Confirmation page button sizing
export const PAYMENT_CONFIRMATION_BUTTON_WIDTH = '290px';
export const PAYMENT_CONFIRMATION_BUTTON_HEIGHT = '48px';

export const BUTTON_WIDTH_MD = '200px';
export const BUTTON_WIDTH_LG = '290px';
export const BUTTON_HEIGHT_SM = '40px';
export const BUTTON_HEIGHT_MD = '48px';
