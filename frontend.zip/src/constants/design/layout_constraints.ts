export const PAGE_MAX_WIDTH = '1000';
